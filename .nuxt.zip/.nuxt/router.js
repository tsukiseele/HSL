import Vue from 'vue'
import Router from 'vue-router'
import { normalizeURL, decode } from 'ufo'
import { interopDefault } from './utils'
import scrollBehavior from './router.scrollBehavior.js'

const _0bf974e6 = () => interopDefault(import('..\\pages\\about\\index.vue' /* webpackChunkName: "pages/about/index" */))
const _5a1718c4 = () => interopDefault(import('..\\pages\\friends\\index.vue' /* webpackChunkName: "pages/friends/index" */))
const _c307847e = () => interopDefault(import('..\\pages\\gallery\\index.vue' /* webpackChunkName: "pages/gallery/index" */))
const _35555432 = () => interopDefault(import('..\\pages\\projects\\index.vue' /* webpackChunkName: "pages/projects/index" */))
const _31cb7080 = () => interopDefault(import('..\\pages\\timeline\\index.vue' /* webpackChunkName: "pages/timeline/index" */))
const _2d19fc78 = () => interopDefault(import('..\\pages\\archives\\_id.vue' /* webpackChunkName: "pages/archives/_id" */))
const _5c2ad60b = () => interopDefault(import('..\\pages\\category\\_id.vue' /* webpackChunkName: "pages/category/_id" */))
const _a5ffcbc6 = () => interopDefault(import('..\\pages\\post\\_page.vue' /* webpackChunkName: "pages/post/_page" */))
const _24c0a2e1 = () => interopDefault(import('..\\pages\\index.vue' /* webpackChunkName: "pages/index" */))

const emptyFn = () => {}

Vue.use(Router)

export const routerOptions = {
  mode: 'history',
  base: '/',
  linkActiveClass: 'nuxt-link-active',
  linkExactActiveClass: 'nuxt-link-exact-active',
  scrollBehavior,

  routes: [{
    path: "/about",
    component: _0bf974e6,
    name: "about"
  }, {
    path: "/friends",
    component: _5a1718c4,
    name: "friends"
  }, {
    path: "/gallery",
    component: _c307847e,
    name: "gallery"
  }, {
    path: "/projects",
    component: _35555432,
    name: "projects"
  }, {
    path: "/timeline",
    component: _31cb7080,
    name: "timeline"
  }, {
    path: "/archives/:id?",
    component: _2d19fc78,
    name: "archives-id"
  }, {
    path: "/category/:id?",
    component: _5c2ad60b,
    name: "category-id"
  }, {
    path: "/post/:page?",
    component: _a5ffcbc6,
    name: "post-page"
  }, {
    path: "/",
    component: _24c0a2e1,
    name: "index"
  }],

  fallback: false
}

export function createRouter (ssrContext, config) {
  const base = (config._app && config._app.basePath) || routerOptions.base
  const router = new Router({ ...routerOptions, base  })

  // TODO: remove in Nuxt 3
  const originalPush = router.push
  router.push = function push (location, onComplete = emptyFn, onAbort) {
    return originalPush.call(this, location, onComplete, onAbort)
  }

  const resolve = router.resolve.bind(router)
  router.resolve = (to, current, append) => {
    if (typeof to === 'string') {
      to = normalizeURL(to)
    }
    return resolve(to, current, append)
  }

  return router
}
