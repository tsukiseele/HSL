export const SComment = () => import('../..\\components\\SComment.vue' /* webpackChunkName: "components/s-comment" */).then(c => wrapFunctional(c.default || c))
export const SDialog = () => import('../..\\components\\SDialog.vue' /* webpackChunkName: "components/s-dialog" */).then(c => wrapFunctional(c.default || c))
export const TheAPlayer = () => import('../..\\components\\TheAPlayer.vue' /* webpackChunkName: "components/the-a-player" */).then(c => wrapFunctional(c.default || c))
export const TheBackTop = () => import('../..\\components\\TheBackTop.vue' /* webpackChunkName: "components/the-back-top" */).then(c => wrapFunctional(c.default || c))
export const TheFooter = () => import('../..\\components\\TheFooter.vue' /* webpackChunkName: "components/the-footer" */).then(c => wrapFunctional(c.default || c))
export const TheInfoCard = () => import('../..\\components\\TheInfoCard.vue' /* webpackChunkName: "components/the-info-card" */).then(c => wrapFunctional(c.default || c))
export const TheLive2d = () => import('../..\\components\\TheLive2d.vue' /* webpackChunkName: "components/the-live2d" */).then(c => wrapFunctional(c.default || c))
export const TheLive2dTools = () => import('../..\\components\\TheLive2dTools.vue' /* webpackChunkName: "components/the-live2d-tools" */).then(c => wrapFunctional(c.default || c))
export const SChip = () => import('../..\\components\\SChip\\index.vue' /* webpackChunkName: "components/s-chip" */).then(c => wrapFunctional(c.default || c))
export const SLink = () => import('../..\\components\\SLink\\index.vue' /* webpackChunkName: "components/s-link" */).then(c => wrapFunctional(c.default || c))
export const SLabelClouds = () => import('../..\\components\\SLabelClouds\\index.vue' /* webpackChunkName: "components/s-label-clouds" */).then(c => wrapFunctional(c.default || c))
export const SPagination = () => import('../..\\components\\SPagination\\index.vue' /* webpackChunkName: "components/s-pagination" */).then(c => wrapFunctional(c.default || c))
export const SIcon = () => import('../..\\components\\SIcon\\index.vue' /* webpackChunkName: "components/s-icon" */).then(c => wrapFunctional(c.default || c))
export const SMarkdown = () => import('../..\\components\\SMarkdown\\index.vue' /* webpackChunkName: "components/s-markdown" */).then(c => wrapFunctional(c.default || c))
export const SPostItem = () => import('../..\\components\\SPostItem\\index.vue' /* webpackChunkName: "components/s-post-item" */).then(c => wrapFunctional(c.default || c))
export const SSimpleWaterfall = () => import('../..\\components\\SSimpleWaterfall\\index.vue' /* webpackChunkName: "components/s-simple-waterfall" */).then(c => wrapFunctional(c.default || c))
export const STitleNav = () => import('../..\\components\\STitleNav\\index.vue' /* webpackChunkName: "components/s-title-nav" */).then(c => wrapFunctional(c.default || c))
export const TheBanner = () => import('../..\\components\\TheBanner\\index.vue' /* webpackChunkName: "components/the-banner" */).then(c => wrapFunctional(c.default || c))
export const SWaterfallIndexOld = () => import('../..\\components\\SWaterfall\\index-old.vue' /* webpackChunkName: "components/s-waterfall-index-old" */).then(c => wrapFunctional(c.default || c))
export const SWaterfall = () => import('../..\\components\\SWaterfall\\index.vue' /* webpackChunkName: "components/s-waterfall" */).then(c => wrapFunctional(c.default || c))
export const SWaterfallIndex2 = () => import('../..\\components\\SWaterfall\\index2.vue' /* webpackChunkName: "components/s-waterfall-index2" */).then(c => wrapFunctional(c.default || c))
export const TheBannerOld = () => import('../..\\components\\TheBannerOld\\index.vue' /* webpackChunkName: "components/the-banner-old" */).then(c => wrapFunctional(c.default || c))
export const TheCategory = () => import('../..\\components\\TheCategory\\index.vue' /* webpackChunkName: "components/the-category" */).then(c => wrapFunctional(c.default || c))
export const TheNav = () => import('../..\\components\\TheNav\\index.vue' /* webpackChunkName: "components/the-nav" */).then(c => wrapFunctional(c.default || c))

// nuxt/nuxt.js#8607
function wrapFunctional(options) {
  if (!options || !options.functional) {
    return options
  }

  const propKeys = Array.isArray(options.props) ? options.props : Object.keys(options.props || {})

  return {
    render(h) {
      const attrs = {}
      const props = {}

      for (const key in this.$attrs) {
        if (propKeys.includes(key)) {
          props[key] = this.$attrs[key]
        } else {
          attrs[key] = this.$attrs[key]
        }
      }

      return h(options, {
        on: this.$listeners,
        attrs,
        props,
        scopedSlots: this.$scopedSlots,
      }, this.$slots.default)
    }
  }
}
