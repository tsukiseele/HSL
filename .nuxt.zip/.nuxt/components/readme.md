# Discovered Components

This is an auto-generated list of components discovered by [nuxt/components](https://github.com/nuxt/components).

You can directly use them in pages and other components without the need to import them.

**Tip:** If a component is conditionally rendered with `v-if` and is big, it is better to use `Lazy` or `lazy-` prefix to lazy load.

- `<SComment>` | `<s-comment>` (components/SComment.vue)
- `<SDialog>` | `<s-dialog>` (components/SDialog.vue)
- `<TheAPlayer>` | `<the-a-player>` (components/TheAPlayer.vue)
- `<TheBackTop>` | `<the-back-top>` (components/TheBackTop.vue)
- `<TheFooter>` | `<the-footer>` (components/TheFooter.vue)
- `<TheInfoCard>` | `<the-info-card>` (components/TheInfoCard.vue)
- `<TheLive2d>` | `<the-live2d>` (components/TheLive2d.vue)
- `<TheLive2dTools>` | `<the-live2d-tools>` (components/TheLive2dTools.vue)
- `<SChip>` | `<s-chip>` (components/SChip/index.vue)
- `<SLink>` | `<s-link>` (components/SLink/index.vue)
- `<SLabelClouds>` | `<s-label-clouds>` (components/SLabelClouds/index.vue)
- `<SPagination>` | `<s-pagination>` (components/SPagination/index.vue)
- `<SIcon>` | `<s-icon>` (components/SIcon/index.vue)
- `<SMarkdown>` | `<s-markdown>` (components/SMarkdown/index.vue)
- `<SPostItem>` | `<s-post-item>` (components/SPostItem/index.vue)
- `<SSimpleWaterfall>` | `<s-simple-waterfall>` (components/SSimpleWaterfall/index.vue)
- `<STitleNav>` | `<s-title-nav>` (components/STitleNav/index.vue)
- `<TheBanner>` | `<the-banner>` (components/TheBanner/index.vue)
- `<SWaterfallIndexOld>` | `<s-waterfall-index-old>` (components/SWaterfall/index-old.vue)
- `<SWaterfall>` | `<s-waterfall>` (components/SWaterfall/index.vue)
- `<SWaterfallIndex2>` | `<s-waterfall-index2>` (components/SWaterfall/index2.vue)
- `<TheBannerOld>` | `<the-banner-old>` (components/TheBannerOld/index.vue)
- `<TheCategory>` | `<the-category>` (components/TheCategory/index.vue)
- `<TheNav>` | `<the-nav>` (components/TheNav/index.vue)
